from __future__ import annotations

import argparse
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline

from detector import clean_text

logger = logging.getLogger("train_model")

DEFAULT_TEXT_COLS = ["title", "company_profile", "description", "requirements", "benefits"]
LIMITATIONS = (
    "Trained on job-posting text (EMSCAD-style). Short SMS/WhatsApp messages differ in "
    "length and style, so scores on them are less reliable. Labels in the source dataset "
    "may contain errors, and results should not be read as proof that a job is fraudulent."
)


@dataclass
class TrainConfig:
    data_path: Path
    text_cols: List[str] = field(default_factory=lambda: list(DEFAULT_TEXT_COLS))
    label_col: str = "fraudulent"
    model_path: Path = Path("model.joblib")
    metrics_path: Path = Path("metrics.json")
    errors_path: Path = Path("test_errors.csv")
    min_recall: float = 0.80
    test_size: float = 0.20
    val_size: float = 0.20
    min_chars: int = 20
    seed: int = 42
    tune: bool = False


def load_and_clean(cfg: TrainConfig) -> Tuple[pd.DataFrame, Dict[str, int]]:
    df = pd.read_csv(cfg.data_path)
    report: Dict[str, int] = {"rows_loaded": int(len(df))}
    logger.info("Loaded %s rows from %s", f"{len(df):,}", cfg.data_path)

    missing = [c for c in cfg.text_cols + [cfg.label_col] if c not in df.columns]
    if missing:
        raise SystemExit(f"Columns not found in CSV: {missing}. Available: {list(df.columns)}")


    df["text"] = (
        df[cfg.text_cols].fillna("").astype(str).agg(" ".join, axis=1).map(clean_text)
    )


    df["label"] = pd.to_numeric(df[cfg.label_col], errors="coerce")
    before = len(df)
    df = df[df["label"].isin([0, 1])].copy()
    df["label"] = df["label"].astype(int)
    report["dropped_invalid_labels"] = int(before - len(df))


    before = len(df)
    df = df[df["text"].str.len() >= cfg.min_chars]
    report["dropped_empty_or_short"] = int(before - len(df))


    label_counts = df.groupby("text")["label"].nunique()
    conflicting = set(label_counts[label_counts > 1].index)
    before = len(df)
    df = df[~df["text"].isin(conflicting)]
    report["dropped_conflicting_labels"] = int(before - len(df))


    before = len(df)
    df = df.drop_duplicates(subset="text")
    report["dropped_duplicates"] = int(before - len(df))

    report["rows_clean"] = int(len(df))
    report["fraud_rows"] = int(df["label"].sum())
    for key, value in report.items():
        logger.info("  %-28s %s", key, f"{value:,}")
    logger.info("Fraud rate after cleaning: %.2f%%", 100 * df["label"].mean())

    if df["label"].nunique() < 2:
        raise SystemExit("After cleaning, only one class is left - cannot train a classifier.")
    return df[["text", "label"]].reset_index(drop=True), report


def build_pipeline(C: float = 1.0, seed: int = 42) -> Pipeline:
    return Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    ngram_range=(1, 2),
                    min_df=3,
                    max_df=0.9,
                    max_features=50_000,
                    sublinear_tf=True,
                    stop_words="english",
                ),
            ),
            (
                "clf",
                LogisticRegression(
                    C=C,
                    class_weight="balanced",
                    max_iter=2000,
                    solver="liblinear",
                    random_state=seed,
                ),
            ),
        ]
    )


def split_data(df: pd.DataFrame, cfg: TrainConfig):
    X_train, X_rest, y_train, y_rest = train_test_split(
        df["text"],
        df["label"],
        test_size=cfg.test_size + cfg.val_size,
        stratify=df["label"],
        random_state=cfg.seed,
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_rest,
        y_rest,
        test_size=cfg.test_size / (cfg.test_size + cfg.val_size),
        stratify=y_rest,
        random_state=cfg.seed,
    )
    logger.info("Split sizes - train %s | validation %s | test %s",
                f"{len(X_train):,}", f"{len(X_val):,}", f"{len(X_test):,}")
    return X_train, X_val, X_test, y_train, y_val, y_test


def fit_model(X_train, y_train, cfg: TrainConfig) -> Pipeline:
    if not cfg.tune:
        pipe = build_pipeline(seed=cfg.seed)
        pipe.fit(X_train, y_train)
        return pipe

    logger.info("Tuning regularisation strength C with 3-fold cross-validation (scoring: F1)")
    search = GridSearchCV(
        build_pipeline(seed=cfg.seed),
        param_grid={"clf__C": [0.1, 0.3, 1.0, 3.0, 10.0]},
        scoring="f1",
        cv=StratifiedKFold(n_splits=3, shuffle=True, random_state=cfg.seed),
        n_jobs=-1,
    )
    search.fit(X_train, y_train)
    logger.info("Best C = %s (CV F1 = %.4f)", search.best_params_["clf__C"], search.best_score_)
    return search.best_estimator_


def pick_threshold(y_val, p_val, min_recall: float) -> float:
    precision, recall, thresholds = precision_recall_curve(y_val, p_val)
    precision, recall = precision[:-1], recall[:-1]
    f1 = 2 * precision * recall / np.clip(precision + recall, 1e-12, None)
    allowed = recall >= min_recall
    if allowed.any():
        idx = int(np.argmax(np.where(allowed, f1, -1.0)))
    else:
        logger.warning("No threshold reaches recall >= %.2f; using best-F1 threshold", min_recall)
        idx = int(np.argmax(f1))
    return float(thresholds[idx])


def evaluate(y_true, proba, threshold: float, name: str) -> Dict[str, Any]:
    pred = (np.asarray(proba) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    metrics = {
        "threshold": round(float(threshold), 4),
        "precision": round(float(precision_score(y_true, pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true, pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y_true, pred, zero_division=0)), 4),
        "false_positives": int(fp),
        "false_negatives": int(fn),
        "true_positives": int(tp),
        "true_negatives": int(tn),
        "false_positive_rate": round(float(fp / max(fp + tn, 1)), 4),
    }
    print(f"\n=== {name} (threshold {threshold:.3f}) ===")
    print(f"Confusion matrix [[TN FP] [FN TP]]: [[{tn} {fp}] [{fn} {tp}]]")
    print(classification_report(y_true, pred, target_names=["genuine", "fraud"], zero_division=0))
    print(f"False positives (genuine flagged as fraud): {fp}")
    print(f"False negatives (scams missed):             {fn}")
    return metrics


def print_top_features(pipe: Pipeline, n: int = 15) -> None:
    names = pipe.named_steps["tfidf"].get_feature_names_out()
    coef = pipe.named_steps["clf"].coef_[0]
    order = np.argsort(coef)
    print("\nTerms pushing towards FRAUD:  " + ", ".join(names[order[::-1][:n]]))
    print("Terms pushing towards GENUINE: " + ", ".join(names[order[:n]]))


def save_errors(X_test, y_test, proba, threshold: float, path: Path) -> int:
    frame = pd.DataFrame({"text": X_test.values, "true_label": y_test.values, "score": proba})
    frame["predicted"] = (frame["score"] >= threshold).astype(int)
    errors = frame[frame["predicted"] != frame["true_label"]].copy()
    errors["error_type"] = np.where(errors["predicted"] == 1, "false_positive", "false_negative")
    errors["text"] = errors["text"].str.slice(0, 300)
    errors.sort_values("score", ascending=False).to_csv(path, index=False)
    return int(len(errors))


def run(cfg: TrainConfig) -> None:
    df, cleaning_report = load_and_clean(cfg)
    X_train, X_val, X_test, y_train, y_val, y_test = split_data(df, cfg)

    pipe = fit_model(X_train, y_train, cfg)
    threshold = pick_threshold(y_val, pipe.predict_proba(X_val)[:, 1], cfg.min_recall)
    logger.info("Chosen decision threshold: %.4f (validation, min recall %.2f)", threshold, cfg.min_recall)


    p_test = pipe.predict_proba(X_test)[:, 1]
    metrics: Dict[str, Any] = {
        "test_at_default_0.5": evaluate(y_test, p_test, 0.5, "TEST @ default 0.5"),
        "test_at_chosen_threshold": evaluate(y_test, p_test, threshold, "TEST @ chosen threshold"),
        "roc_auc": round(float(roc_auc_score(y_test, p_test)), 4),
        "average_precision": round(float(average_precision_score(y_test, p_test)), 4),
        "sizes": {"train": int(len(X_train)), "validation": int(len(X_val)), "test": int(len(X_test))},
        "test_fraud_count": int(y_test.sum()),
        "cleaning_report": cleaning_report,
        "limitations": LIMITATIONS,
    }
    print(f"\nROC-AUC: {metrics['roc_auc']}   Average precision (PR-AUC): {metrics['average_precision']}")
    print_top_features(pipe)

    n_errors = save_errors(X_test, y_test, p_test, threshold, cfg.errors_path)
    logger.info("Wrote %d misclassified test messages to %s", n_errors, cfg.errors_path)

    bundle = {
        "pipeline": pipe,
        "threshold": threshold,
        "metadata": {
            "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "sklearn_version": sklearn.__version__,
            "n_clean_rows": cleaning_report["rows_clean"],
            "text_cols": cfg.text_cols,
            "min_recall": cfg.min_recall,
            "tuned": cfg.tune,
        },
    }
    joblib.dump(bundle, cfg.model_path)
    cfg.metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    logger.info("Saved model to %s and metrics to %s", cfg.model_path, cfg.metrics_path)


def parse_args(argv=None) -> TrainConfig:
    parser = argparse.ArgumentParser(description="Train the job-scam detector.")
    parser.add_argument("--data", required=True, type=Path, help="path to fake_job_postings.csv")
    parser.add_argument("--text-cols", nargs="+", default=DEFAULT_TEXT_COLS)
    parser.add_argument("--label-col", default="fraudulent")
    parser.add_argument("--min-recall", type=float, default=0.80,
                        help="minimum fraud recall required when choosing the threshold")
    parser.add_argument("--tune", action="store_true", help="grid-search the regularisation strength")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", type=Path, default=Path("model.joblib"))
    args = parser.parse_args(argv)
    return TrainConfig(
        data_path=args.data,
        text_cols=args.text_cols,
        label_col=args.label_col,
        min_recall=args.min_recall,
        tune=args.tune,
        seed=args.seed,
        model_path=args.out,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
    run(parse_args())
