# Job Scam Detector

Machine-learning component for the RMIT hackathon recruitment-scam project. Viresh’s module provides a risk score and supporting warning signs for a job message. It is a prototype, not a definitive fraud-verification service.

## Files

- `detector.py` — message classification API and command-line interface
- `train_model.py` — dataset preparation, model fitting and held-out evaluation
- `evaluate_samples.py` — exploratory checks on manually written messages
- `test_detector.py` — unit tests using a synthetic model
- `requirements.txt` — required Python packages

## Install

```bash
python -m venv .venv
```

Activate your environment with `.venv\Scripts\activate` (Windows) or `source .venv/bin/activate` (macOS/Linux), then install dependencies:

```bash
pip install -r requirements.txt
```

## Train

Place the labelled `fake_job_postings.csv` dataset in this folder and run:

```bash
python train_model.py --data fake_job_postings.csv
```

You can optionally use `--tune` to search over regularisation values. The training command writes `model.joblib`, `metrics.json`, and `test_errors.csv`. Only quote evaluation scores after running on the real dataset. Verify dataset licensing before redistributing it.

## Run

```bash
python detector.py "Pay a registration fee to secure your job" --json
python evaluate_samples.py
python -m unittest -v test_detector.py
```

## Integration

```python
from detector import predict, predict_batch, predict_score

result = predict("Pay a registration fee before the interview")
print(result["prediction"], result["score"], result["risk_band"])

scores = predict_batch(["Invitation to interview", "Pay a fee now"])
fraud_probability = predict_score("Unusual recruitment request")
```

`prediction` uses `1` for potentially fraudulent and `0` otherwise. `score` is the model's estimated fraud probability; `risk_band` can be `low`, `review`, or `high`. Warning signs are separately detected and do not alter the model score. Empty input is returned as `review` with a `0.0` placeholder score; inspect the label before displaying it as a probability.

## Scope and limitations

The pipeline uses cleaned job-posting text, TF-IDF features, and class-weighted Logistic Regression. Data is split into separate training, validation, and test sets. The validation set is used to select a decision threshold, and the test set reports precision, recall, F1, and false positives.

A model trained on job advertisements can behave differently on short chat messages, miss sophisticated scams, or flag genuine messages. Rule-based warning signs are indicators rather than evidence of confirmed fraud. The handwritten examples and synthetic unit-test data are not substitutes for real held-out evaluation.
