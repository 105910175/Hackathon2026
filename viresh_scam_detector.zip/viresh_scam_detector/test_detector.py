import random
import tempfile
import unittest
from pathlib import Path

import joblib

from detector import ScamDetector, clean_text, detect_warning_signs
from train_model import build_pipeline

GOOD_WORDS = ("team engineer office salary interview resume benefits experience degree manager "
              "project skills company hiring developer analyst").split()
BAD_WORDS = ("fee payment urgent wire transfer earn fast home easy bank deposit guaranteed "
             "whatsapp limited registration").split()


def make_toy_model(path: Path) -> None:
    rng = random.Random(0)
    texts, labels = [], []
    for i in range(300):
        fraud = i % 5 == 0
        words = rng.choices(GOOD_WORDS, k=40) + (rng.choices(BAD_WORDS, k=15) if fraud else [])
        rng.shuffle(words)
        texts.append(" ".join(words))
        labels.append(int(fraud))
    pipe = build_pipeline()
    pipe.fit(texts, labels)
    joblib.dump({"pipeline": pipe, "threshold": 0.5, "metadata": {}}, path)


class CleanTextTests(unittest.TestCase):
    def test_replaces_urls_emails_money_phone(self):
        out = clean_text("Email jobs@firm.com or visit https://firm.com. Pay $50. Call +61 400 123 456")
        for token in ("emailtoken", "urltoken", "moneytoken", "phonetoken"):
            self.assertIn(token, out)

    def test_handles_none_nan_and_html(self):
        self.assertEqual(clean_text(None), "")
        self.assertEqual(clean_text(float("nan")), "")
        self.assertEqual(clean_text("<p>Hello&nbsp;World</p>"), "hello world")


class WarningSignTests(unittest.TestCase):
    def ids(self, text):
        return {s.id for s in detect_warning_signs(text)}

    def test_detects_upfront_payment_and_transfer(self):
        found = self.ids("Pay a registration fee by wire transfer.")
        self.assertIn("upfront_payment", found)
        self.assertIn("money_transfer", found)

    def test_detects_urgency_pay_and_chat_app(self):
        found = self.ids("URGENT! Earn $500 per day, message us on WhatsApp.")
        self.assertTrue({"urgency", "unrealistic_pay", "off_platform_contact"} <= found)

    def test_missing_interview(self):
        self.assertIn("missing_interview", self.ids("Congratulations, you have been selected!"))
        self.assertNotIn("missing_interview",
                         self.ids("Congratulations, we would like to schedule an interview."))

    def test_benign_message_has_no_signs(self):
        self.assertEqual(self.ids("Join our engineering team. Interview next week in our office."), set())


class DetectorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        path = Path(cls.tmp.name) / "model.joblib"
        make_toy_model(path)
        cls.detector = ScamDetector(path)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_result_structure(self):
        result = self.detector.predict("Pay a registration fee by wire transfer, urgent bank deposit").to_dict()
        for key in ("prediction", "score", "label", "risk_band", "threshold",
                    "top_terms", "warning_signs", "caveats", "note"):
            self.assertIn(key, result)
        self.assertTrue(0.0 <= result["score"] <= 1.0)
        self.assertIn(result["risk_band"], {"low", "review", "high"})

    def test_scam_scores_higher_than_genuine(self):
        scam = self.detector.predict("urgent fee payment wire transfer guaranteed bank deposit").score
        good = self.detector.predict("engineer team interview resume degree manager project").score
        self.assertGreater(scam, good)

    def test_empty_message(self):
        result = self.detector.predict("   ")
        self.assertEqual(result.score, 0.0)
        self.assertEqual(result.risk_band, "review")

    def test_non_string_input_does_not_crash(self):
        self.assertEqual(self.detector.predict(None).score, 0.0)
        self.assertIsNotNone(self.detector.predict(12345))

    def test_band_boundaries(self):
        d = self.detector
        self.assertEqual(d._band(d.threshold), "high")
        self.assertEqual(d._band(d.threshold * 0.75), "review")
        self.assertEqual(d._band(d.threshold * 0.1), "low")

    def test_missing_model_file(self):
        with self.assertRaises(FileNotFoundError):
            ScamDetector(Path(self.tmp.name) / "nope.joblib")


if __name__ == "__main__":
    unittest.main()
