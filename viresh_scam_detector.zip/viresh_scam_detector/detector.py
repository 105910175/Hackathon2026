from __future__ import annotations

import argparse
import html
import json
import logging
import os
import re
import sys
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import joblib
import numpy as np

logger = logging.getLogger(__name__)


DEFAULT_MODEL_PATH = Path(
    os.environ.get("SCAM_MODEL_PATH", Path(__file__).resolve().parent / "model.joblib")
)
MAX_INPUT_CHARS = 20_000
SHORT_MESSAGE_WORDS = 15
REVIEW_RATIO = 0.5


_URL_RE = re.compile(r"(https?://\S+|www\.\S+)", re.IGNORECASE)
_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
_PHONE_RE = re.compile(r"(\+?\d[\d\s().-]{7,}\d)")
_TAG_RE = re.compile(r"<[^>]+>")
_MONEY_RE = re.compile(r"[$£€₹]\s?\d[\d,]*(\.\d+)?")
_WS_RE = re.compile(r"\s+")


def clean_text(text: Any) -> str:
    if text is None or (isinstance(text, float) and np.isnan(text)):
        return ""
    text = html.unescape(str(text))
    text = _TAG_RE.sub(" ", text)
    text = _URL_RE.sub(" urltoken ", text)
    text = _EMAIL_RE.sub(" emailtoken ", text)
    text = _MONEY_RE.sub(" moneytoken ", text)
    text = _PHONE_RE.sub(" phonetoken ", text)
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s']", " ", text)
    return _WS_RE.sub(" ", text).strip()


_I = re.IGNORECASE

_SIGN_RULES: Dict[str, Tuple[str, "re.Pattern[str]"]] = {
    "upfront_payment": (
        "Asks for a fee or payment up front",
        re.compile(
            r"\b(registration|processing|training|application|security|admin(istration)?|"
            r"onboarding|equipment|starter[- ]kit|background[- ]check|verification)\s+"
            r"(fee|charge|payment|deposit|costs?)\b"
            r"|\b(pay|send|transfer)\s+(us\s+)?(a|an|the|your)?\s*(small\s+)?(fee|deposit|payment)\b"
            r"|\bup-?front\b|\badvance (fee|payment)\b|\brefundable deposit\b",
            _I,
        ),
    ),
    "money_transfer": (
        "Mentions risky ways of moving money",
        re.compile(
            r"\bwire transfer\b|\bwestern union\b|\bmoneygram\b|\bgift cards?\b|\bbitcoin\b"
            r"|\bcrypto(currency)?\b|\bzelle\b|\bcheque\b|\bcheck deposit\b"
            r"|\bbank (details|account|transfer)\b|\b(transfer|forward) (the )?(remaining )?(funds|money)\b",
            _I,
        ),
    ),
    "unrealistic_pay": (
        "Promises unusually high or guaranteed pay for little work",
        re.compile(
            r"[$£€]\s?\d{3,}(,\d{3})*\s*(/|per|a|each)\s*(day|week|hour|assignment)\b"
            r"|\bearn\s+(up to\s+)?[$£€]\s?\d{3,}"
            r"|\bguaranteed (income|salary|earnings|profit)\b|\beasy money\b"
            r"|\bno experience (needed|required|necessary)\b"
            r"|\bwork (just |only )?\d+\s*(hours?|hrs)\s*(a|per)\s*(day|week)\b"
            r"|\bget paid (daily|instantly)\b",
            _I,
        ),
    ),
    "urgency": (
        "Uses urgency or pressure",
        re.compile(
            r"\burgent(ly)?\b|\bimmediate(ly)?\b|\bact now\b"
            r"|\blimited (slots|spots|time|positions|vacancies)\b|\btoday only\b"
            r"|\bwithin (24|48) hours\b|\bhurry\b|\basap\b|\blast chance\b|\bexpires? (today|soon)\b",
            _I,
        ),
    ),
    "off_platform_contact": (
        "Moves the conversation to a private chat app",
        re.compile(r"\bwhats\s?app\b|\btelegram\b|\bwechat\b|\b(text|dm|message) (us|me)\b", _I),
    ),
    "sensitive_info": (
        "Asks for sensitive personal or financial details",
        re.compile(
            r"\b(social security|ssn|tax file number|tfn|passport( number| copy| scan)?|"
            r"driver'?s licen[sc]e|credit card|card numbers?|cvv|online banking|bank login|"
            r"password|pin number)\b|\bcopy of your id\b",
            _I,
        ),
    ),
}

_OFFER_RE = re.compile(
    r"\byou('ve| have)? been (selected|hired|chosen|shortlisted)\b|\bcongratulations\b"
    r"|\bjob offer\b|\bstart (work )?immediately\b",
    _I,
)
_NO_INTERVIEW_RE = re.compile(r"\bno interview\b", _I)
_INTERVIEW_RE = re.compile(r"\binterview\b", _I)


@dataclass
class WarningSign:


    id: str
    label: str
    evidence: List[str] = field(default_factory=list)


def detect_warning_signs(message: str) -> List[WarningSign]:
    text = message or ""
    signs: List[WarningSign] = []

    for sign_id, (label, pattern) in _SIGN_RULES.items():
        matches = [m.group(0).strip().lower() for m in pattern.finditer(text)]
        if matches:
            unique = list(dict.fromkeys(matches))[:3]
            signs.append(WarningSign(sign_id, label, unique))

    if _NO_INTERVIEW_RE.search(text):
        signs.append(WarningSign("missing_interview", "Offers a job with no interview", ["no interview"]))
    elif _OFFER_RE.search(text) and not _INTERVIEW_RE.search(text):
        offer = _OFFER_RE.search(text).group(0).strip().lower()
        signs.append(WarningSign("missing_interview", "Offers a job without mentioning an interview", [offer]))

    return signs


_LABELS = {
    "high": "Potentially fraudulent",
    "review": "Uncertain - needs human review",
    "low": "Likely legitimate",
}

_NOTES = {
    "high": (
        "The model rates this message as similar to known fraudulent job postings. "
        "This is a statistical estimate, not proof - verify the employer through an "
        "official source before sharing money or personal details."
    ),
    "review": (
        "The model is not confident either way. A person should check this message "
        "and verify the employer independently."
    ),
    "low": (
        "The model rates this message as similar to genuine job postings. That does "
        "not guarantee it is safe - it can miss scams, so still verify the employer."
    ),
}


@dataclass
class PredictionResult:
    prediction: int
    score: float
    label: str
    risk_band: str
    threshold: float
    top_terms: List[str]
    warning_signs: List[Dict[str, Any]]
    caveats: List[str]
    note: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ScamDetector:


    def __init__(self, model_path: Optional[os.PathLike] = None, review_ratio: float = REVIEW_RATIO):
        self.model_path = Path(model_path) if model_path else DEFAULT_MODEL_PATH
        self.review_ratio = review_ratio
        bundle = self._load(self.model_path)
        self.pipeline = bundle["pipeline"]
        self.threshold = float(bundle["threshold"])
        self.metadata: Dict[str, Any] = bundle.get("metadata", {})
        self._tfidf = self.pipeline.named_steps["tfidf"]
        self._clf = self.pipeline.named_steps["clf"]
        self._feature_names = self._tfidf.get_feature_names_out()


    @staticmethod
    def _load(path: Path) -> Dict[str, Any]:
        if not path.exists():
            raise FileNotFoundError(
                f"Model file not found at {path}. "
                "Run `python train_model.py --data <csv>` first, or set SCAM_MODEL_PATH."
            )
        bundle = joblib.load(path)
        if not isinstance(bundle, dict) or "pipeline" not in bundle or "threshold" not in bundle:
            raise ValueError(f"{path} is not a valid model bundle (needs 'pipeline' and 'threshold').")
        steps = getattr(bundle["pipeline"], "named_steps", {})
        if "tfidf" not in steps or "clf" not in steps:
            raise ValueError("Pipeline must contain steps named 'tfidf' and 'clf'.")
        return bundle


    def _band(self, score: float) -> str:
        if score >= self.threshold:
            return "high"
        if score >= self.threshold * self.review_ratio:
            return "review"
        return "low"

    def _top_terms(self, cleaned: str, n: int = 5) -> List[str]:
        row = self._tfidf.transform([cleaned])
        if row.nnz == 0:
            return []
        contrib = row.multiply(self._clf.coef_[0]).tocoo()
        pairs = [(v, self._feature_names[j]) for j, v in zip(contrib.col, contrib.data) if v > 0]
        pairs.sort(reverse=True)
        return [term for _, term in pairs[:n]]

    @staticmethod
    def _coerce(message: Any) -> str:
        if message is None:
            return ""
        text = message if isinstance(message, str) else str(message)
        if len(text) > MAX_INPUT_CHARS:
            logger.warning("Input truncated from %d to %d characters", len(text), MAX_INPUT_CHARS)
            text = text[:MAX_INPUT_CHARS]
        return text


    def predict(self, message: Any) -> PredictionResult:
        text = self._coerce(message)
        cleaned = clean_text(text)

        if not cleaned:
            return PredictionResult(
                prediction=0,
                score=0.0,
                label="No text to analyse",
                risk_band="review",
                threshold=round(self.threshold, 4),
                top_terms=[],
                warning_signs=[],
                caveats=["The message was empty."],
                note="There was no text to analyse, so no score was produced.",
            )

        score = float(self.pipeline.predict_proba([cleaned])[0, 1])
        band = self._band(score)
        signs = detect_warning_signs(text)

        caveats = [
            "The model was trained on job-posting ads, not SMS/WhatsApp messages, "
            "so scores on chat-style messages are less reliable."
        ]
        if len(cleaned.split()) < SHORT_MESSAGE_WORDS:
            caveats.append("This message is very short, so the score is less reliable.")
        if band == "low" and len(signs) >= 2:
            caveats.append(
                f"The model score is low, but {len(signs)} warning signs were found. "
                "Treat the message with caution."
            )

        return PredictionResult(
            prediction=int(score >= self.threshold),
            score=round(score, 4),
            label=_LABELS[band],
            risk_band=band,
            threshold=round(self.threshold, 4),
            top_terms=self._top_terms(cleaned),
            warning_signs=[asdict(s) for s in signs],
            caveats=caveats,
            note=_NOTES[band],
        )

    def predict_batch(self, messages: Iterable[Any]) -> List[PredictionResult]:
        return [self.predict(m) for m in messages]


@lru_cache(maxsize=1)
def get_detector() -> ScamDetector:
    return ScamDetector()


def predict(message: Any) -> Dict[str, Any]:
    return get_detector().predict(message).to_dict()


def predict_score(message: Any) -> float:
    return get_detector().predict(message).score


def predict_batch(messages: Iterable[Any]) -> List[Dict[str, Any]]:
    return [r.to_dict() for r in get_detector().predict_batch(messages)]


def _main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Score a job message for scam risk.")
    parser.add_argument("message", nargs="*", help="message text (or use --file / stdin)")
    parser.add_argument("--file", help="read the message from a text file")
    parser.add_argument("--json", action="store_true", help="print the full result as JSON")
    parser.add_argument("--model", help="path to model.joblib")
    args = parser.parse_args(argv)

    if args.file:
        text = Path(args.file).read_text(encoding="utf-8")
    elif args.message:
        text = " ".join(args.message)
    else:
        text = sys.stdin.read() if not sys.stdin.isatty() else input("Paste a job message: ")

    detector = ScamDetector(args.model) if args.model else get_detector()
    result = detector.predict(text).to_dict()

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Label:   {result['label']}")
        print(f"Score:   {result['score']:.3f} (threshold {result['threshold']:.3f})")
        print(f"Band:    {result['risk_band']}")
        if result["top_terms"]:
            print(f"Terms:   {', '.join(result['top_terms'])}")
        for sign in result["warning_signs"]:
            print(f"Warning: {sign['label']} ({', '.join(sign['evidence'])})")
        for caveat in result["caveats"]:
            print(f"Caveat:  {caveat}")
        print(f"\n{result['note']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
