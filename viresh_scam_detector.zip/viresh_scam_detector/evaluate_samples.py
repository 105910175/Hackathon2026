from __future__ import annotations

import textwrap

import pandas as pd

from detector import predict

SAMPLES = [

    ("legitimate", "Hi Priya, thanks for applying for the Junior Data Analyst role at Northwind "
     "Logistics. We would like to invite you to a 30-minute video interview on Tuesday at 2pm. "
     "The position is based in our Melbourne office, salary range $65,000 to $75,000 plus "
     "superannuation. Please reply to confirm, and see the full position description on our careers page."),
    ("legitimate", "Software Engineer (Backend) at Harbour Analytics. You will design and maintain "
     "Python services, work with a small team of engineers and take part in code reviews. "
     "Requirements: a degree in computer science or equivalent experience and 2+ years of SQL. "
     "We offer flexible hours, health benefits and a learning budget. Apply through our website."),
    ("legitimate", "We received your application for Customer Support Officer. Our recruiter will "
     "contact you from our company email to arrange a phone screening. No payment or personal "
     "documents are needed at this stage."),

    ("scam", "CONGRATULATIONS! You have been selected for a work from home job. Earn $500 per day "
     "with no experience needed. To start immediately you must pay an $80 registration fee by "
     "wire transfer. Reply on WhatsApp now, limited spots!"),
    ("scam", "URGENT hiring! Data entry, only 2 hours a day, guaranteed income of $3000 a week. "
     "No interview required. Send your passport copy and bank account details to receive your "
     "starter kit. Contact us on Telegram today only."),
    ("scam", "Dear applicant, your resume was approved. We will send you a cheque to buy office "
     "equipment from our vendor. Deposit the cheque and transfer the remaining funds to our "
     "supplier within 24 hours."),
    ("scam", "Mystery shopper wanted! Get paid $400 per assignment. We send a gift card; you buy "
     "items, then send us the card numbers and a payment for the training fee."),

    ("ambiguous", "Hi, we have a flexible remote role for a part-time assistant. Pay is good and "
     "hours are your choice. Message me on WhatsApp for details."),
    ("ambiguous", "Congratulations, you have been shortlisted for the Sales Associate role. Please "
     "send a copy of your ID and your bank details so payroll can set you up before your first day."),
    ("ambiguous", "Earn extra income as a brand ambassador. Commission only, uncapped earnings, "
     "training provided. The starter kit costs $30, refundable after your first sale."),
]


def main() -> None:
    rows = []
    for category, text in SAMPLES:
        result = predict(text)
        rows.append(
            {
                "category": category,
                "score": result["score"],
                "prediction": result["prediction"],
                "risk_band": result["risk_band"],
                "warning_signs": ", ".join(s["id"] for s in result["warning_signs"]),
                "top_terms": ", ".join(result["top_terms"]),
                "text": textwrap.shorten(text, 90),
            }
        )

    report = pd.DataFrame(rows)
    pd.set_option("display.width", 200)
    pd.set_option("display.max_colwidth", 60)
    print(report.to_string(index=False))

    legit = report[report["category"] == "legitimate"]
    scams = report[report["category"] == "scam"]
    print("\nSummary (small hand-written set - not a substitute for the held-out test metrics)")
    print(f"  Legitimate flagged as fraud (false positives): {int((legit['prediction'] == 1).sum())} of {len(legit)}")
    print(f"  Obvious scams missed (false negatives):        {int((scams['prediction'] == 0).sum())} of {len(scams)}")
    print(f"  Ambiguous cases for human review: bands = "
          f"{report[report['category'] == 'ambiguous']['risk_band'].tolist()}")

    report.to_csv("samples_report.csv", index=False)
    print("\nSaved samples_report.csv")


if __name__ == "__main__":
    main()
